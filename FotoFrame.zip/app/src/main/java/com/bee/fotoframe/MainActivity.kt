package com.bee.fotoframe

import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.print.PrintHelper
import java.io.*
import java.net.*
import kotlin.concurrent.thread

val BG = 0xFF0F1115.toInt()
val PANEL = 0xFF171A21.toInt()
val FG = 0xFFE8EAED.toInt()
val ACC = 0xFFF5A623.toInt()
val BTN = 0xFF2A2F3A.toInt()
const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

class Adj(var bri: Int = 0, var con: Int = 0, var sat: Int = 100, var warm: Int = 0) {
    fun reset() { bri = 0; con = 0; sat = 100; warm = 0 }
}
class TextItem(var text: String, var x: Float = 0.5f, var y: Float = 0.5f, var size: Float = 0.07f,
               var color: Int = Color.WHITE, var font: Int = 0, var bold: Boolean = false, var shadow: Boolean = true)
class FrameData(val bmp: Bitmap, val mask: Bitmap, val hole: RectF)
class FrameSrc(val name: String, val asset: String?, val file: File?)

fun cmOf(a: Adj): ColorMatrix {
    val m = ColorMatrix(); m.setSaturation(a.sat / 100f)
    val c = (100 + a.con) / 100f
    val t = 128f * (1 - c) + a.bri * 2.55f
    val rw = 1 + a.warm / 400f; val bw = 1 - a.warm / 400f
    m.postConcat(ColorMatrix(floatArrayOf(c * rw, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c * bw, 0f, t, 0f, 0f, 0f, 1f, 0f)))
    return m
}

fun hueCM(deg: Float): ColorMatrix {
    val r = Math.toRadians(deg.toDouble()); val c = Math.cos(r).toFloat(); val s = Math.sin(r).toFloat()
    return ColorMatrix(floatArrayOf(
        0.213f + c * 0.787f - s * 0.213f, 0.715f - c * 0.715f - s * 0.715f, 0.072f - c * 0.072f + s * 0.928f, 0f, 0f,
        0.213f - c * 0.213f + s * 0.143f, 0.715f + c * 0.285f + s * 0.140f, 0.072f - c * 0.072f - s * 0.283f, 0f, 0f,
        0.213f - c * 0.213f - s * 0.787f, 0.715f - c * 0.715f + s * 0.715f, 0.072f + c * 0.928f + s * 0.072f, 0f, 0f,
        0f, 0f, 0f, 1f, 0f))
}

// Area foto = piksel transparan (frame bawaan) atau putih polos (frame tambahan) yang terhubung ke tengah.
fun prepareFrame(src: Bitmap): FrameData {
    val w = src.width; val h = src.height
    val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
    fun like(c: Int): Boolean {
        if ((c ushr 24) < 16) return true
        val r = (c shr 16) and 255; val g = (c shr 8) and 255; val b = c and 255
        return minOf(r, g, b) >= 190 && maxOf(r, g, b) - minOf(r, g, b) <= 14
    }
    var stack = IntArray(1 shl 16)
    fun fill(sx: Int, sy: Int, tgt: BooleanArray) {
        val s0 = sy * w + sx
        if (tgt[s0] || !like(px[s0])) return
        var sp = 0
        stack[sp++] = s0; tgt[s0] = true
        while (sp > 0) {
            val i = stack[--sp]; val x = i % w; val y = i / w
            for (k in 0..3) {
                val nx = x + (if (k == 0) -1 else if (k == 1) 1 else 0)
                val ny = y + (if (k == 2) -1 else if (k == 3) 1 else 0)
                if (nx < 0 || ny < 0 || nx >= w || ny >= h) continue
                val j = ny * w + nx
                if (tgt[j] || !like(px[j])) continue
                tgt[j] = true
                if (sp == stack.size) stack = stack.copyOf(sp * 2)
                stack[sp++] = j
            }
        }
    }
    val hole = BooleanArray(w * h); fill(w / 2, h / 2, hole)
    val outer = BooleanArray(w * h)
    fill(0, 0, outer); fill(w - 1, 0, outer); fill(0, h - 1, outer); fill(w - 1, h - 1, outer)
    var x0 = w; var y0 = h; var x1 = -1; var y1 = -1; var cnt = 0
    for (y in 0 until h) for (x in 0 until w) {
        val i = y * w + x
        if (hole[i]) {
            cnt++; if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y
            px[i] = 0
        } else if (outer[i]) px[i] = 0
    }
    var cur = hole
    val ok = cnt > 1000
    if (!ok) cur = BooleanArray(w * h) { true }
    else repeat(2) {
        val nx = BooleanArray(w * h)
        for (y in 0 until h) for (x in 0 until w) {
            val i = y * w + x
            if (cur[i] || (x > 0 && cur[i - 1]) || (x < w - 1 && cur[i + 1]) || (y > 0 && cur[i - w]) || (y < h - 1 && cur[i + w])) nx[i] = true
        }
        cur = nx
    }
    val mp = IntArray(w * h) { if (cur[it]) -16777216 else 0 }
    val mask = Bitmap.createBitmap(mp, w, h, Bitmap.Config.ARGB_8888)
    val rect = if (ok) RectF(x0.toFloat(), y0.toFloat(), (x1 + 1).toFloat(), (y1 + 1).toFloat()) else RectF(0f, 0f, w.toFloat(), h.toFloat())
    return FrameData(Bitmap.createBitmap(px, w, h, Bitmap.Config.ARGB_8888), mask, rect)
}

fun loadBitmap(ctx: Context, uri: Uri, max: Int): Bitmap? = try {
    val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (maxOf(o.outWidth, o.outHeight) / s > max) s *= 2
    val o2 = BitmapFactory.Options(); o2.inSampleSize = s
    var b = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
    val deg = try {
        ctx.contentResolver.openInputStream(uri)?.use {
            when (android.media.ExifInterface(it).getAttributeInt(android.media.ExifInterface.TAG_ORIENTATION, 1)) {
                6 -> 90; 3 -> 180; 8 -> 270; else -> 0
            }
        } ?: 0
    } catch (e: Exception) { 0 }
    if (b != null && deg != 0) {
        val m = Matrix(); m.postRotate(deg.toFloat())
        b = Bitmap.createBitmap(b, 0, 0, b.width, b.height, m, true)
    }
    b
} catch (e: Exception) { null }

class EditorView(ctx: Context) : View(ctx) {
    var frame: FrameData? = null
    var photo: Bitmap? = null
    var pScale = 1f; var pDx = 0f; var pDy = 0f; var pRot = 0f
    val photoAdj = Adj(); val frameAdj = Adj(); val finalAdj = Adj()
    var tint = 0; var hue = 0f; var bg = Color.BLACK
    val texts = ArrayList<TextItem>()
    var sel: TextItem? = null
    var onSelect: ((TextItem?) -> Unit)? = null
    var onEmptyTap: (() -> Unit)? = null
    var scaleCb: ((Float) -> Unit)? = null
    var exporting = false
    var vs = 1f; var ox = 0f; var oy = 0f
    var dragText: TextItem? = null
    var lx = 0f; var ly = 0f; var sx = 0f; var sy = 0f; var moved = false
    val fonts = arrayOf("sans-serif", "serif", "cursive", "monospace", "sans-serif-condensed")

    val sd = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            if (dragText == null) {
                pScale = (pScale * d.scaleFactor).coerceIn(0.2f, 5f)
                scaleCb?.invoke(pScale); invalidate()
            }
            return true
        }
    })

    fun cw() = frame?.bmp?.width ?: 1080
    fun ch() = frame?.bmp?.height ?: 1350

    fun setPhoto(b: Bitmap) { photo = b; pScale = 1f; pDx = 0f; pDy = 0f; pRot = 0f; invalidate() }
    fun resetAll() {
        photoAdj.reset(); frameAdj.reset(); finalAdj.reset()
        tint = 0; hue = 0f; pScale = 1f; pDx = 0f; pDy = 0f; pRot = 0f
        texts.clear(); sel = null; invalidate()
    }

    fun frameCM(): ColorMatrix {
        val m = ColorMatrix()
        if (tint != 0) {
            m.setSaturation(0f); val k = 1.7f
            m.postConcat(ColorMatrix(floatArrayOf(
                Color.red(tint) / 255f * k, 0f, 0f, 0f, 0f,
                0f, Color.green(tint) / 255f * k, 0f, 0f, 0f,
                0f, 0f, Color.blue(tint) / 255f * k, 0f, 0f,
                0f, 0f, 0f, 1f, 0f)))
        } else if (hue != 0f) m.postConcat(hueCM(hue))
        m.postConcat(cmOf(frameAdj))
        return m
    }

    fun tpaint(t: TextItem, W: Float): Paint {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = t.size * W; p.color = t.color; p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(fonts[t.font], if (t.bold) Typeface.BOLD else Typeface.NORMAL)
        if (t.shadow) p.setShadowLayer(p.textSize * 0.08f, 0f, p.textSize * 0.04f, 0xCC000000.toInt())
        return p
    }

    fun textRect(t: TextItem): RectF {
        val W = cw().toFloat(); val p = tpaint(t, W)
        val ls = t.text.split("\n"); val lh = p.textSize * 1.2f
        val bw = ls.maxOf { p.measureText(it) }
        val cx = t.x * W; val cy = t.y * ch()
        return RectF(cx - bw / 2 - 20, cy - ls.size * lh / 2 - 10, cx + bw / 2 + 20, cy + ls.size * lh / 2 + 10)
    }

    fun drawTextItem(c: Canvas, t: TextItem, showSel: Boolean) {
        val W = cw().toFloat(); val p = tpaint(t, W)
        val ls = t.text.split("\n"); val lh = p.textSize * 1.2f
        val top = t.y * ch() - ls.size * lh / 2
        ls.forEachIndexed { i, l -> c.drawText(l, t.x * W, top + i * lh + lh * 0.5f + p.textSize * 0.33f, p) }
        if (showSel) {
            val sp = Paint(Paint.ANTI_ALIAS_FLAG)
            sp.style = Paint.Style.STROKE; sp.color = ACC; sp.strokeWidth = 4f / vs
            sp.pathEffect = DashPathEffect(floatArrayOf(16f / vs, 10f / vs), 0f)
            c.drawRect(textRect(t), sp)
        }
    }

    fun render(c: Canvas) {
        val W = cw().toFloat(); val H = ch().toFloat()
        val lp = Paint(); lp.colorFilter = ColorMatrixColorFilter(cmOf(finalAdj))
        c.saveLayer(0f, 0f, W, H, lp)
        c.drawColor(bg)
        val ph = photo; val fr = frame
        if (ph != null) {
            val hole = fr?.hole ?: RectF(0f, 0f, W, H)
            c.saveLayer(0f, 0f, W, H, null)
            val s = maxOf(hole.width() / ph.width, hole.height() / ph.height) * pScale
            c.save()
            c.translate(hole.centerX() + pDx, hole.centerY() + pDy); c.rotate(pRot); c.scale(s, s)
            val pp = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
            pp.colorFilter = ColorMatrixColorFilter(cmOf(photoAdj))
            c.drawBitmap(ph, -ph.width / 2f, -ph.height / 2f, pp)
            c.restore()
            if (fr != null) {
                val mp = Paint(); mp.xfermode = PorterDuffXfermode(PorterDuff.Mode.DST_IN)
                c.drawBitmap(fr.mask, 0f, 0f, mp)
            }
            c.restore()
        }
        if (fr != null) {
            val fp = Paint(Paint.FILTER_BITMAP_FLAG); fp.colorFilter = ColorMatrixColorFilter(frameCM())
            c.drawBitmap(fr.bmp, 0f, 0f, fp)
        }
        for (t in texts) drawTextItem(c, t, t === sel && !exporting)
        c.restore()
    }

    fun export(): Bitmap {
        val b = Bitmap.createBitmap(cw(), ch(), Bitmap.Config.ARGB_8888)
        exporting = true; render(Canvas(b)); exporting = false
        return b
    }

    override fun onDraw(c: Canvas) {
        val W = cw().toFloat(); val H = ch().toFloat()
        vs = minOf(width / W, height / H); ox = (width - W * vs) / 2; oy = (height - H * vs) / 2
        c.save(); c.translate(ox, oy); c.scale(vs, vs); c.clipRect(0f, 0f, W, H)
        render(c); c.restore()
        if (photo == null) {
            val p = Paint(Paint.ANTI_ALIAS_FLAG); p.color = 0xFFFFFFFF.toInt()
            p.textSize = context.dp(16).toFloat(); p.textAlign = Paint.Align.CENTER
            p.setShadowLayer(8f, 0f, 2f, 0xFF000000.toInt())
            c.drawText("📷 Ketuk di sini untuk sisipkan foto", width / 2f, height / 2f, p)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        sd.onTouchEvent(e)
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lx = e.x; ly = e.y; sx = e.x; sy = e.y; moved = false
                val cx = (e.x - ox) / vs; val cy = (e.y - oy) / vs
                dragText = texts.lastOrNull { textRect(it).contains(cx, cy) }
                if (dragText != null) { sel = dragText; onSelect?.invoke(sel) }
                invalidate()
            }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount == 1 && !sd.isInProgress) {
                    val dx = (e.x - lx) / vs; val dy = (e.y - ly) / vs
                    lx = e.x; ly = e.y
                    if (Math.abs(e.x - sx) + Math.abs(e.y - sy) > 16) moved = true
                    val dt = dragText
                    if (dt != null) { dt.x += dx / cw(); dt.y += dy / ch() } else { pDx += dx; pDy += dy }
                    invalidate()
                } else { lx = e.x; ly = e.y; moved = true }
            }
            MotionEvent.ACTION_POINTER_UP -> {
                val i = if (e.actionIndex == 0) 1 else 0
                lx = e.getX(i); ly = e.getY(i)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                if (e.actionMasked == MotionEvent.ACTION_UP && !moved && dragText == null) {
                    if (photo == null) onEmptyTap?.invoke()
                    else if (sel != null) { sel = null; onSelect?.invoke(null) }
                }
                dragText = null; invalidate()
            }
        }
        return true
    }
}

class PhotoServer(val port: Int, val onFile: (ByteArray) -> Unit) {
    @Volatile var running = false
    var ss: ServerSocket? = null
    val page = """<!doctype html><html><head><meta name=viewport content="width=device-width,initial-scale=1"><meta charset=utf-8><title>Kirim Foto</title></head><body style="background:#0f1115;color:#eee;font-family:sans-serif;text-align:center;padding:30px"><h2>Kirim foto ke Foto Frame</h2><form method=post enctype=multipart/form-data><p><input type=file name=f accept="image/*" style="font-size:18px"></p><p><button style="font-size:22px;padding:16px 40px;background:#f5a623;border:0;border-radius:12px">Kirim</button></p></form></body></html>"""
    fun start() {
        ss = ServerSocket(port); running = true
        thread(isDaemon = true) {
            while (running) {
                try { val s = ss!!.accept(); thread { handle(s) } } catch (e: Exception) { break }
            }
        }
    }
    fun stop() { running = false; try { ss?.close() } catch (e: Exception) {} }
    fun reply(o: OutputStream, html: String) {
        val b = html.toByteArray()
        o.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + b.size + "\r\nConnection: close\r\n\r\n").toByteArray())
        o.write(b); o.flush()
    }
    fun find(a: ByteArray, p: ByteArray, from: Int): Int {
        var i = from
        while (i <= a.size - p.size) {
            var k = 0
            while (k < p.size && a[i + k] == p[k]) k++
            if (k == p.size) return i
            i++
        }
        return -1
    }
    fun findLast(a: ByteArray, p: ByteArray): Int {
        var i = a.size - p.size
        while (i >= 0) {
            var k = 0
            while (k < p.size && a[i + k] == p[k]) k++
            if (k == p.size) return i
            i--
        }
        return -1
    }
    fun handle(s: Socket) {
        s.use {
            try {
                s.soTimeout = 30000
                val inp = BufferedInputStream(s.getInputStream()); val out = s.getOutputStream()
                val head = StringBuilder()
                while (true) {
                    val c = inp.read(); if (c < 0) return
                    head.append(c.toChar())
                    if (head.endsWith("\r\n\r\n")) break
                    if (head.length > 16384) return
                }
                val hs = head.toString()
                if (hs.startsWith("POST")) {
                    val len = Regex("(?i)content-length:\\s*(\\d+)").find(hs)?.groupValues?.get(1)?.toInt() ?: 0
                    val bd = Regex("(?i)boundary=([^\\r\\n;]+)").find(hs)?.groupValues?.get(1)?.trim()?.trim('"')
                    if (len <= 0 || len > 60000000 || bd == null) { reply(out, "Permintaan tidak valid"); return }
                    val body = ByteArray(len); var off = 0
                    while (off < len) { val n = inp.read(body, off, len - off); if (n < 0) break; off += n }
                    val he = find(body, "\r\n\r\n".toByteArray(), 0)
                    val en = findLast(body, ("\r\n--" + bd).toByteArray())
                    if (he >= 0 && en > he + 4) {
                        onFile(body.copyOfRange(he + 4, en))
                        reply(out, "<html><meta name=viewport content='width=device-width'><body style='background:#0f1115;color:#eee;font-family:sans-serif;text-align:center;padding:40px'><h2>Foto terkirim &#10003;</h2><a style='color:#f5a623' href='/'>Kirim lagi</a></body></html>")
                    } else reply(out, "Foto tidak terbaca")
                } else reply(out, page)
            } catch (e: Exception) {}
        }
    }
}

class MainActivity : Activity() {
    lateinit var ed: EditorView
    lateinit var panel: FrameLayout
    lateinit var main: LinearLayout
    lateinit var tabs: View
    lateinit var gallery: ScrollView
    lateinit var galleryGrid: GridLayout
    lateinit var side: LinearLayout
    lateinit var sideWrap: ScrollView
    lateinit var handle: TextView
    lateinit var prefs: SharedPreferences
    val labels = ArrayList<TextView>()
    val tabBtns = ArrayList<TextView>()
    val frames = ArrayList<FrameSrc>()
    val thumbs = HashMap<String, Bitmap>()
    var mode = 1; var tab = 1; var curFrame = -1
    var inGallery = true
    var server: PhotoServer? = null
    var camUri: Uri? = null
    var scaleSeek: SeekBar? = null

    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    fun round(c: Int, r: Int) = GradientDrawable().apply { setColor(c); cornerRadius = r.toFloat() }
    fun marg(w: Int = WRAP, h: Int = WRAP, wt: Float = 0f) =
        LinearLayout.LayoutParams(w, h, wt).apply { setMargins(dp(4), dp(4), dp(4), dp(4)) }

    fun btn(t: String, accent: Boolean = false, onClick: () -> Unit): TextView {
        val v = TextView(this); v.text = t
        v.setTextColor(if (accent) 0xFF111111.toInt() else FG); v.textSize = 14f
        v.gravity = Gravity.CENTER; v.setPadding(dp(14), dp(10), dp(14), dp(10)); v.minHeight = dp(48)
        v.background = round(if (accent) ACC else BTN, dp(10))
        v.setOnClickListener { onClick() }
        return v
    }

    fun hint(t: String): TextView { val v = TextView(this); v.text = t; v.setTextColor(0xFF9AA0A6.toInt()); v.textSize = 13f; v.setPadding(dp(4), dp(8), dp(4), dp(8)); return v }

    fun row(vararg v: View): LinearLayout {
        val r = LinearLayout(this)
        for (x in v) r.addView(x, marg(0, WRAP, 1f))
        return r
    }
    fun hrow(vararg v: View): HorizontalScrollView {
        val h = HorizontalScrollView(this); val r = LinearLayout(this)
        for (x in v) r.addView(x, marg())
        h.addView(r); return h
    }

    fun slider(label: String, min: Int, max: Int, init: Int, onCh: (Int) -> Unit): LinearLayout {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        val tv = TextView(this); tv.setTextColor(FG); tv.textSize = 13f
        val v0 = init.coerceIn(min, max); tv.text = label + ": " + v0
        val sb = SeekBar(this); sb.max = max - min; sb.progress = v0 - min
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) {
                tv.text = label + ": " + (p + min); if (u) onCh(p + min)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        col.addView(tv); col.addView(sb, LinearLayout.LayoutParams(MATCH, dp(40)))
        col.tag = sb
        return col
    }

    fun swatches(cols: IntArray, onPick: (Int) -> Unit): View {
        val h = HorizontalScrollView(this); val r = LinearLayout(this)
        for (c in cols) {
            val v = TextView(this); v.text = if (c == 0) "∅" else ""; v.gravity = Gravity.CENTER; v.setTextColor(FG)
            v.background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL; setColor(if (c == 0) BTN else c); setStroke(dp(2), 0x88FFFFFF.toInt())
            }
            v.setOnClickListener { onPick(c) }
            r.addView(v, marg(dp(48), dp(48)))
        }
        h.addView(r); return h
    }

    fun choice(title: String, opts: List<String>, sel: Int, on: (Int) -> Unit): View {
        val c = LinearLayout(this); c.orientation = LinearLayout.VERTICAL; c.setPadding(0, dp(8), 0, dp(8))
        val t = TextView(this); t.text = title; t.setTypeface(null, Typeface.BOLD)
        val g = RadioGroup(this); g.orientation = RadioGroup.HORIZONTAL
        opts.forEachIndexed { i, o ->
            val r = RadioButton(this); r.text = o; r.id = View.generateViewId(); g.addView(r)
            if (i == sel) r.isChecked = true
            r.setOnClickListener { on(i) }
        }
        c.addView(t); c.addView(g); return c
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = BG
        prefs = getSharedPreferences("s", 0)
        ed = EditorView(this); ed.bg = prefs.getInt("bg", Color.BLACK)
        ed.onSelect = { if (tab == 3) showPanel(3) }
        ed.onEmptyTap = { pick(1) }
        val root = FrameLayout(this); root.setBackgroundColor(BG)
        main = LinearLayout(this); main.orientation = LinearLayout.VERTICAL
        main.addView(topBar())
        val content = FrameLayout(this)
        content.addView(ed, FrameLayout.LayoutParams(MATCH, MATCH))
        gallery = ScrollView(this); gallery.setBackgroundColor(BG)
        galleryGrid = GridLayout(this); galleryGrid.columnCount = 2
        galleryGrid.setPadding(dp(8), dp(8), dp(8), dp(8))
        gallery.addView(galleryGrid)
        content.addView(gallery, FrameLayout.LayoutParams(MATCH, MATCH))
        main.addView(content, LinearLayout.LayoutParams(MATCH, 0, 1f))
        tabs = tabBar()
        main.addView(tabs)
        panel = FrameLayout(this); panel.setBackgroundColor(PANEL)
        main.addView(panel, LinearLayout.LayoutParams(MATCH, dp(230)))
        root.addView(main, FrameLayout.LayoutParams(MATCH, MATCH))
        buildSide()
        root.addView(sideWrap, FrameLayout.LayoutParams(dp(60), MATCH, Gravity.START))
        handle = TextView(this); handle.text = "▶"; handle.setTextColor(0xFF111111.toInt()); handle.gravity = Gravity.CENTER
        handle.background = round(0xCCF5A623.toInt(), dp(8))
        handle.setOnClickListener { mode = 2; applyMode() }
        root.addView(handle, FrameLayout.LayoutParams(dp(24), dp(96), Gravity.START or Gravity.CENTER_VERTICAL))
        setContentView(root)
        applyMode(); loadFrameList()
        showGallery(true)
        handleIntent(intent)
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i); handleIntent(i) }
    override fun onDestroy() { super.onDestroy(); server?.stop() }
    override fun onBackPressed() {
        if (!inGallery) showGallery(true) else super.onBackPressed()
    }

    fun handleIntent(i: Intent?) {
        if (i == null) return
        if (i.action == Intent.ACTION_SEND && i.type?.startsWith("image/") == true) {
            @Suppress("DEPRECATION") val u = i.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            if (u != null) loadPhoto(u)
        } else if (i.action == Intent.ACTION_SEND_MULTIPLE) {
            @Suppress("DEPRECATION") val u = i.getParcelableArrayListExtra<Uri>(Intent.EXTRA_STREAM)?.firstOrNull()
            if (u != null) loadPhoto(u)
        }
    }

    fun topBar(): View {
        val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL; r.setBackgroundColor(PANEL)
        val m = TextView(this); m.text = "☰"; m.textSize = 24f; m.setTextColor(FG); m.gravity = Gravity.CENTER
        m.setOnClickListener { mode = if (mode == 2) 1 else 2; applyMode() }
        r.addView(m, LinearLayout.LayoutParams(dp(56), dp(56)))
        val t = TextView(this); t.text = "Foto Frame"; t.setTextColor(FG); t.textSize = 18f
        r.addView(t, LinearLayout.LayoutParams(0, WRAP, 1f))
        r.addView(btn("💾 Simpan", true) { save(false) }, marg())
        return r
    }

    fun tabBar(): View {
        val h = HorizontalScrollView(this); h.setBackgroundColor(BG)
        val r = LinearLayout(this)
        listOf("🖼 Ganti Frame", "📷 Foto", "🎨 Warna Frame", "🔤 Teks", "✨ Hasil").forEachIndexed { i, n ->
            val b = btn(n) { if (i == 0) showGallery(true) else showPanel(i) }; tabBtns.add(b); r.addView(b, marg())
        }
        h.addView(r); return h
    }

    fun buildSide() {
        side = LinearLayout(this); side.orientation = LinearLayout.VERTICAL
        sideWrap = ScrollView(this); sideWrap.setBackgroundColor(0xFF12151B.toInt()); sideWrap.elevation = dp(16).toFloat()
        sideWrap.addView(side); side.setPadding(0, dp(24), 0, dp(8))
        fun item(e: String, l: String, a: () -> Unit) {
            val r = LinearLayout(this); r.orientation = LinearLayout.HORIZONTAL; r.gravity = Gravity.CENTER_VERTICAL
            val ic = TextView(this); ic.text = e; ic.textSize = 22f; ic.gravity = Gravity.CENTER; ic.setTextColor(FG)
            r.addView(ic, LinearLayout.LayoutParams(dp(60), dp(56)))
            val tv = TextView(this); tv.text = l; tv.setTextColor(FG); tv.textSize = 15f
            r.addView(tv); labels.add(tv)
            r.setOnClickListener { a(); if (mode == 2) { mode = 1; applyMode() } }
            side.addView(r, LinearLayout.LayoutParams(MATCH, dp(56)))
        }
        item("◀", "Sembunyikan") { mode = 0; applyMode() }
        item("🖼", "Pilih / Ganti Frame") { showGallery(true) }
        item("📂", "Pilih Foto") { pick(1) }
        item("📸", "Kamera") { camera() }
        item("🔗", "Koneksi (terima foto)") { connDialog() }
        item("💾", "Simpan ke Galeri") { save(false) }
        item("📤", "Bagikan") { save(true) }
        item("🖨", "Opsi Print") { printDialog() }
        item("⚙", "Pengaturan") { settingsDialog() }
        item("♻", "Reset Semua") { ed.resetAll(); if (!inGallery) showPanel(tab) }
        item("ℹ", "Tentang") { toast("Foto Frame 1.0 — frame tetap, foto bebas diatur") }
    }

    fun applyMode() {
        sideWrap.visibility = if (mode == 0) View.GONE else View.VISIBLE
        handle.visibility = if (mode == 0) View.VISIBLE else View.GONE
        val lp = sideWrap.layoutParams; lp.width = if (mode == 2) dp(230) else dp(60); sideWrap.layoutParams = lp
        val mp = main.layoutParams as FrameLayout.LayoutParams; mp.leftMargin = if (mode == 0) 0 else dp(60); main.layoutParams = mp
        labels.forEach { it.visibility = if (mode == 2) View.VISIBLE else View.GONE }
        if (inGallery) buildGallery()
    }

    fun pick(code: Int) {
        val i = Intent(Intent.ACTION_GET_CONTENT); i.type = "image/*"
        startActivityForResult(i, code)
    }

    fun camera() {
        try {
            val cv = ContentValues(); cv.put(MediaStore.Images.Media.DISPLAY_NAME, "cam_" + System.currentTimeMillis() + ".jpg")
            cv.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            camUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            val i = Intent(MediaStore.ACTION_IMAGE_CAPTURE); i.putExtra(MediaStore.EXTRA_OUTPUT, camUri)
            startActivityForResult(i, 2)
        } catch (e: Exception) { toast("Kamera tidak tersedia") }
    }

    override fun onActivityResult(rq: Int, rs: Int, d: Intent?) {
        super.onActivityResult(rq, rs, d)
        if (rs != RESULT_OK) return
        when (rq) {
            1 -> d?.data?.let { loadPhoto(it) }
            2 -> camUri?.let { loadPhoto(it) }
            3 -> d?.data?.let { addFrame(it) }
        }
    }

    fun loadPhoto(u: Uri) {
        thread {
            val b = loadBitmap(this, u, 2600)
            runOnUiThread {
                if (b != null) {
                    ed.setPhoto(b)
                    if (inGallery) showGallery(false)
                    if (tab == 1) showPanel(1)
                } else toast("Foto gagal dibuka")
            }
        }
    }

    fun onReceived(bytes: ByteArray) {
        try {
            val f = File(cacheDir, "rx_" + System.currentTimeMillis() + ".jpg"); f.writeBytes(bytes)
            loadPhoto(Uri.fromFile(f)); runOnUiThread { toast("Foto diterima") }
        } catch (e: Exception) {}
    }

    fun loadFrameList() {
        frames.clear()
        (assets.list("frames") ?: arrayOf()).filter { val n = it.lowercase(); n.endsWith(".png") || n.endsWith(".jpg") || n.endsWith(".webp") }
            .sorted().forEach { frames.add(FrameSrc(it, it, null)) }
        File(filesDir, "frames").listFiles()?.sortedBy { it.name }?.forEach { frames.add(FrameSrc(it.name, null, it)) }
    }

    fun addFrame(u: Uri) {
        try {
            val dir = File(filesDir, "frames"); dir.mkdirs()
            val f = File(dir, "f" + System.currentTimeMillis() + ".png")
            contentResolver.openInputStream(u)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
            loadFrameList(); buildGallery(); chooseFrame(frames.size - 1)
        } catch (e: Exception) { toast("Gagal menambah frame") }
    }

    fun decodeSrc(s: FrameSrc, max: Int): Bitmap? {
        try {
            fun open(): InputStream = if (s.asset != null) assets.open("frames/" + s.asset) else FileInputStream(s.file!!)
            val o = BitmapFactory.Options(); o.inJustDecodeBounds = true
            open().use { BitmapFactory.decodeStream(it, null, o) }
            var sm = 1
            while (maxOf(o.outWidth, o.outHeight) / sm > max) sm *= 2
            val o2 = BitmapFactory.Options(); o2.inSampleSize = sm
            return open().use { BitmapFactory.decodeStream(it, null, o2) }
        } catch (e: Exception) { return null }
    }

    // Pilih frame dari galeri: proses frame, lalu masuk editor dan minta foto bila belum ada.
    fun chooseFrame(i: Int) {
        curFrame = i
        toast("Memproses frame…")
        thread {
            val b = decodeSrc(frames[i], 2000)
            val fd = b?.let { prepareFrame(it) }
            runOnUiThread {
                ed.frame = fd; ed.pDx = 0f; ed.pDy = 0f; ed.invalidate()
                showGallery(false)
                if (ed.photo == null) pick(1)
            }
        }
    }

    fun showGallery(on: Boolean) {
        inGallery = on
        gallery.visibility = if (on) View.VISIBLE else View.GONE
        tabs.visibility = if (on) View.GONE else View.VISIBLE
        panel.visibility = if (on) View.GONE else View.VISIBLE
        if (on) buildGallery() else showPanel(if (tab == 0) 1 else tab)
    }

    fun buildGallery() {
        galleryGrid.removeAllViews()
        val avail = resources.displayMetrics.widthPixels - (if (mode == 0) 0 else dp(60)) - dp(16)
        val cw = avail / 2 - dp(8); val chh = (cw * 1.35f).toInt()
        fun add(v: View) {
            val lp = GridLayout.LayoutParams(); lp.width = cw; lp.height = chh; lp.setMargins(dp(4), dp(4), dp(4), dp(4))
            galleryGrid.addView(v, lp)
        }
        frames.forEachIndexed { i, f ->
            val iv = ImageView(this); iv.scaleType = ImageView.ScaleType.FIT_CENTER; iv.setPadding(dp(6), dp(6), dp(6), dp(6))
            iv.background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(0xFFFFFFFF.toInt()); if (i == curFrame) setStroke(dp(3), ACC) }
            iv.setOnClickListener { chooseFrame(i) }
            if (f.file != null) iv.setOnLongClickListener {
                AlertDialog.Builder(this).setTitle("Hapus frame ini?")
                    .setPositiveButton("Hapus") { _, _ ->
                        f.file.delete(); thumbs.remove(f.name); curFrame = -1; ed.frame = null
                        loadFrameList(); buildGallery()
                    }.setNegativeButton("Batal", null).show()
                true
            }
            val cached = thumbs[f.name]
            if (cached != null) iv.setImageBitmap(cached)
            else thread { val b = decodeSrc(f, 360); if (b != null) { thumbs[f.name] = b; runOnUiThread { iv.setImageBitmap(b) } } }
            add(iv)
        }
        val plus = TextView(this); plus.text = "＋\nFrame baru"; plus.gravity = Gravity.CENTER; plus.setTextColor(FG); plus.textSize = 16f
        plus.background = GradientDrawable().apply { cornerRadius = dp(12).toFloat(); setColor(BTN) }
        plus.setOnClickListener { pick(3) }
        add(plus)
    }

    fun showPanel(i: Int) {
        tab = i; panel.removeAllViews()
        tabBtns.forEachIndexed { k, b -> b.background = round(if (k == i) ACC else BTN, dp(10)); b.setTextColor(if (k == i) 0xFF111111.toInt() else FG) }
        val sv = ScrollView(this); val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(12), dp(8), dp(12), dp(8)); sv.addView(col); panel.addView(sv)
        when (i) { 1 -> photoPanel(col); 2 -> colorPanel(col); 3 -> textPanel(col); 4 -> finalPanel(col) }
    }

    fun photoPanel(col: LinearLayout) {
        col.addView(row(btn("📂 Ganti foto") { pick(1) }, btn("📸 Kamera") { camera() }))
        col.addView(hint("Seret foto untuk geser, cubit untuk zoom. Frame tetap."))
        val s = slider("Ukuran foto (%)", 20, 500, (ed.pScale * 100).toInt()) { ed.pScale = it / 100f; ed.invalidate() }
        scaleSeek = s.tag as SeekBar
        ed.scaleCb = { v -> scaleSeek?.progress = (v * 100).toInt().coerceIn(20, 500) - 20 }
        col.addView(s)
        col.addView(slider("Rotasi (°)", -180, 180, ed.pRot.toInt()) { ed.pRot = it.toFloat(); ed.invalidate() })
        col.addView(slider("Kecerahan", -100, 100, ed.photoAdj.bri) { ed.photoAdj.bri = it; ed.invalidate() })
        col.addView(slider("Kontras", -100, 100, ed.photoAdj.con) { ed.photoAdj.con = it; ed.invalidate() })
        col.addView(slider("Saturasi", 0, 200, ed.photoAdj.sat) { ed.photoAdj.sat = it; ed.invalidate() })
        col.addView(slider("Kehangatan", -100, 100, ed.photoAdj.warm) { ed.photoAdj.warm = it; ed.invalidate() })
        col.addView(row(btn("↺ Posisi") { ed.pScale = 1f; ed.pDx = 0f; ed.pDy = 0f; ed.pRot = 0f; ed.invalidate(); showPanel(1) },
            btn("↺ Cahaya") { ed.photoAdj.reset(); ed.invalidate(); showPanel(1) }))
    }

    fun colorPanel(col: LinearLayout) {
        col.addView(hint("Warna frame (∅ = warna asli)"))
        col.addView(swatches(intArrayOf(0, 0xFFD4AF37.toInt(), 0xFFC0392B.toInt(), 0xFF2E5CB8.toInt(), 0xFF2E8B57.toInt(),
            0xFF8E44AD.toInt(), 0xFFE91E8C.toInt(), 0xFFC0C0C0.toInt(), 0xFF8B5A2B.toInt(), 0xFF333333.toInt())) { ed.tint = it; ed.invalidate() })
        col.addView(slider("Putar warna (hue)", 0, 360, ed.hue.toInt()) { ed.hue = it.toFloat(); ed.tint = 0; ed.invalidate() })
        col.addView(slider("Kecerahan frame", -100, 100, ed.frameAdj.bri) { ed.frameAdj.bri = it; ed.invalidate() })
        col.addView(slider("Kontras frame", -100, 100, ed.frameAdj.con) { ed.frameAdj.con = it; ed.invalidate() })
        col.addView(slider("Saturasi frame", 0, 200, ed.frameAdj.sat) { ed.frameAdj.sat = it; ed.invalidate() })
        col.addView(btn("↺ Reset warna frame") { ed.frameAdj.reset(); ed.tint = 0; ed.hue = 0f; ed.invalidate(); showPanel(2) })
    }

    fun askText(init: String, ok: (String) -> Unit) {
        val et = EditText(this); et.setText(init); et.hint = "Tulis kata-kata…"; et.minLines = 2
        AlertDialog.Builder(this).setTitle("Teks").setView(et)
            .setPositiveButton("OK") { _, _ -> val s = et.text.toString().trim(); if (s.isNotEmpty()) ok(s) }
            .setNegativeButton("Batal", null).show()
    }

    fun textPanel(col: LinearLayout) {
        col.addView(btn("➕ Tambah teks", true) {
            askText("") { s -> val t = TextItem(s); ed.texts.add(t); ed.sel = t; ed.invalidate(); showPanel(3) }
        })
        val t = ed.sel
        if (t == null) { col.addView(hint("Ketuk teks di gambar untuk memilih, lalu seret untuk memindah.")); return }
        col.addView(slider("Ukuran teks", 2, 25, (t.size * 100).toInt()) { t.size = it / 100f; ed.invalidate() })
        col.addView(hrow(*listOf("Sans", "Serif", "Tulisan", "Mono", "Sempit").mapIndexed { i, n ->
            btn(n) { t.font = i; ed.invalidate() } as View }.toTypedArray()))
        col.addView(row(btn("B  Tebal") { t.bold = !t.bold; ed.invalidate() }, btn("Bayangan") { t.shadow = !t.shadow; ed.invalidate() }))
        col.addView(swatches(intArrayOf(Color.WHITE, Color.BLACK, 0xFFD4AF37.toInt(), 0xFFFFEB3B.toInt(), 0xFFE53935.toInt(),
            0xFF1E88E5.toInt(), 0xFF43A047.toInt(), 0xFFEC407A.toInt())) { t.color = it; ed.invalidate() })
        col.addView(row(btn("✏ Edit") { askText(t.text) { s -> t.text = s; ed.invalidate() } },
            btn("🗑 Hapus") { ed.texts.remove(t); ed.sel = null; ed.invalidate(); showPanel(3) }))
    }

    fun finalPanel(col: LinearLayout) {
        col.addView(hint("Pengaturan untuk seluruh hasil (foto + frame + teks)"))
        col.addView(slider("Kecerahan", -100, 100, ed.finalAdj.bri) { ed.finalAdj.bri = it; ed.invalidate() })
        col.addView(slider("Kontras", -100, 100, ed.finalAdj.con) { ed.finalAdj.con = it; ed.invalidate() })
        col.addView(slider("Saturasi", 0, 200, ed.finalAdj.sat) { ed.finalAdj.sat = it; ed.invalidate() })
        col.addView(slider("Kehangatan", -100, 100, ed.finalAdj.warm) { ed.finalAdj.warm = it; ed.invalidate() })
        col.addView(row(btn("↺ Reset") { ed.finalAdj.reset(); ed.invalidate(); showPanel(4) },
            btn("💾 Simpan", true) { save(false) }, btn("🖨 Cetak") { printDialog() }))
    }

    fun localIp(): String {
        try {
            for (ni in java.util.Collections.list(NetworkInterface.getNetworkInterfaces()))
                for (a in java.util.Collections.list(ni.inetAddresses))
                    if (!a.isLoopbackAddress && a is Inet4Address) return a.hostAddress ?: ""
        } catch (e: Exception) {}
        return "?"
    }

    fun connDialog() {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(12), dp(20), dp(12))
        val info = TextView(this); info.textSize = 15f
        val tb = btn("") {}
        val port = prefs.getInt("port", 8080)
        fun refresh() {
            val on = server?.running == true
            info.text = if (on) "Server AKTIF.\nDi HP/komputer lain (satu WiFi atau hotspot) buka:\n\nhttp://" + localIp() + ":" + port + "\n\nPilih foto lalu tekan Kirim — langsung masuk ke editor."
            else "Server mati.\nNyalakan agar perangkat lain bisa mengirim foto lewat WiFi/hotspot.\n\nCara lain: di Galeri pilih Bagikan → Foto Frame."
            tb.text = if (on) "⏹ Matikan server" else "▶ Nyalakan server"
        }
        tb.setOnClickListener {
            if (server?.running == true) { server?.stop(); server = null }
            else try { server = PhotoServer(port) { onReceived(it) }.also { it.start() } } catch (e: Exception) { toast("Gagal: " + e.message) }
            refresh()
        }
        refresh()
        col.addView(info); col.addView(tb, marg(MATCH, WRAP))
        AlertDialog.Builder(this).setTitle("Koneksi").setView(col).setPositiveButton("Tutup", null).show()
    }

    fun settingsDialog() {
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(8), dp(20), dp(8))
        col.addView(choice("Format simpan", listOf("PNG", "JPG"), if (prefs.getString("fmt", "png") == "png") 0 else 1) {
            prefs.edit().putString("fmt", if (it == 0) "png" else "jpg").apply() })
        col.addView(slider("Kualitas JPG", 50, 100, prefs.getInt("q", 92)) { prefs.edit().putInt("q", it).apply() })
        val t = TextView(this); t.text = "Warna latar"; t.setTypeface(null, Typeface.BOLD); t.setPadding(0, dp(12), 0, 0)
        col.addView(t)
        col.addView(swatches(intArrayOf(Color.BLACK, Color.WHITE, 0xFF1B2A49.toInt(), 0xFF3E2723.toInt(), 0xFF1B5E20.toInt(), 0xFF880E4F.toInt())) {
            ed.bg = it; prefs.edit().putInt("bg", it).apply(); ed.invalidate() })
        val sv = ScrollView(this); sv.addView(col)
        AlertDialog.Builder(this).setTitle("Pengaturan").setView(sv).setPositiveButton("Tutup", null).show()
    }

    fun printDialog() {
        if (ed.photo == null) { toast("Pilih foto dulu"); return }
        var fit = 0; var mono = 0; var ori = 0
        val col = LinearLayout(this); col.orientation = LinearLayout.VERTICAL; col.setPadding(dp(20), dp(8), dp(20), dp(8))
        col.addView(choice("Skala", listOf("Pas (fit)", "Penuh (crop)"), 0) { fit = it })
        col.addView(choice("Warna", listOf("Berwarna", "Hitam-putih"), 0) { mono = it })
        col.addView(choice("Orientasi", listOf("Otomatis", "Potret", "Lanskap"), 0) { ori = it })
        AlertDialog.Builder(this).setTitle("Opsi Print").setView(col)
            .setPositiveButton("Cetak") { _, _ ->
                val ph = PrintHelper(this)
                ph.scaleMode = if (fit == 0) PrintHelper.SCALE_MODE_FIT else PrintHelper.SCALE_MODE_FILL
                ph.colorMode = if (mono == 0) PrintHelper.COLOR_MODE_COLOR else PrintHelper.COLOR_MODE_MONOCHROME
                if (ori == 1) ph.orientation = PrintHelper.ORIENTATION_PORTRAIT
                if (ori == 2) ph.orientation = PrintHelper.ORIENTATION_LANDSCAPE
                ph.printBitmap("FotoFrame", ed.export())
            }.setNegativeButton("Batal", null).show()
    }

    fun save(share: Boolean) {
        if (ed.photo == null) { toast("Pilih foto dulu"); return }
        val bmp = ed.export()
        val png = prefs.getString("fmt", "png") == "png"
        val q = prefs.getInt("q", 92)
        val ext = if (png) "png" else "jpg"
        val mime = if (png) "image/png" else "image/jpeg"
        thread {
            val cv = ContentValues()
            cv.put(MediaStore.Images.Media.DISPLAY_NAME, "FotoFrame_" + System.currentTimeMillis() + "." + ext)
            cv.put(MediaStore.Images.Media.MIME_TYPE, mime)
            cv.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/FotoFrame")
            cv.put(MediaStore.Images.Media.IS_PENDING, 1)
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.use { bmp.compress(if (png) Bitmap.CompressFormat.PNG else Bitmap.CompressFormat.JPEG, q, it) }
                cv.clear(); cv.put(MediaStore.Images.Media.IS_PENDING, 0); contentResolver.update(uri, cv, null, null)
            }
            runOnUiThread {
                if (uri == null) { toast("Gagal menyimpan"); return@runOnUiThread }
                toast("Tersimpan di Pictures/FotoFrame")
                if (share) {
                    val i = Intent(Intent.ACTION_SEND); i.type = mime; i.putExtra(Intent.EXTRA_STREAM, uri)
                    i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    startActivity(Intent.createChooser(i, "Bagikan"))
                }
            }
        }
    }
}
